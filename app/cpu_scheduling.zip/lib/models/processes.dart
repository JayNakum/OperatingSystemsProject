import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

class Processes {
  int _timeQuantum = 0;
  final List<Map<String, int>> _processes = [];

  List<Map<String, int>> getProcesses() {
    return _processes;
  }

  void setProcesses(List<Map<String, int>> processes) {
    _processes.clear();
    _processes.addAll(processes);
  }

  void setQuantum(int quantum) {
    _timeQuantum = quantum;
  }

  Future<void> uploadToFirebase(String algorithmName) async {
    await FirebaseFirestore.instance
        .collection('CPU Scheduling')
        .doc(algorithmName)
        .set({'Processes': _processes, 'Time Quantum': _timeQuantum});
  }

  // Future<String> getGanttChart() async {
  //   final ref = FirebaseStorage.instance.ref('output/ganttchart.png');
  //   var url = await ref.getDownloadURL();
  //   // print(url);
  //   return url;
  // }

  // Future<String> getTableChart() async {
  //   final ref = FirebaseStorage.instance.ref('output/outputTable.png');
  //   var url = await ref.getDownloadURL();
  //   // print(url);
  //   return url;
  // }
}
