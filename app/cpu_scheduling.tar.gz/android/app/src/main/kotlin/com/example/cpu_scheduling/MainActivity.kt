package com.example.cpu_scheduling

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
