import 'package:flutter/material.dart';

import '../widgets/app_drawer.dart';
import '../widgets/cards.dart';

class HomeScreen extends StatelessWidget {
  static const routeName = 'home-screen';
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const AppDrawer(),
      appBar: AppBar(
        title: const Text('CPU Scheduling'),
      ),
      body: const Cards(),
    );
  }
}
