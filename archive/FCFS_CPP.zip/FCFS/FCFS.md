# FCFS First Come First Serve
First Come First Serve (FCFS) is an operating system scheduling algorithm that automatically executes queued requests and processes in order of their arrival. It is the easiest and simplest CPU scheduling algorithm. In this type of algorithm, processes which requests the CPU first get the CPU allocation first. This is managed with a FIFO queue. 

<img src="https://github.com/JayNakum/OperatingSystemsProject/blob/main/CPU_scheduling_algorithms/FCFS_output.jpeg">
