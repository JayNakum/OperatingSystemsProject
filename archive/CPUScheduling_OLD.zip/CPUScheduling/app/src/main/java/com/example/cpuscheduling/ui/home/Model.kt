package com.example.cpuscheduling.ui.home

class Model(var title: String, var description: String, var image: Int) {
}